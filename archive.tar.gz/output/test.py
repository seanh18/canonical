for i in range(1, 6):
    file = open("./output/answer" + str(i) + ".txt", "r")
    ans = file.read()
    file.close()
    file = open("./output/out" + str(i) +".txt", "r")
    out = file.read()
    file.close()
    if ans == out:
        print("Test " + str(i) + ": Passed")
    else:
        print("Test " + str(i) + ": Passed")