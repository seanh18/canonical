# trello
creating trello cards

Requirements:
- You will need an active trello.com account that has editing access to at least one board, and one board must contain at least one list.
- You will need python3 installed, along with the requests module (pip install requests)

How to use:
- make run
- make
- python3 trello.py

Next development steps:
- Allow creation of boards
- Allow creation of lists
- Include more modifiable fields for each card
