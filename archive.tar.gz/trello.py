import json
import requests

def makeNote(name, board, idList) -> bool:
    global userInfo

    print("\nEnter the title for the card:\n")
    title = input()
    print("\nEnter the comment for the card\n")
    comment = input()

    url = "https://api.trello.com/1/boards/" + board + "/labels"
    query = {'key': '4f9c2c7240849c11b5c5d3723d08c7a4', 'token': userInfo[name][0]}
    response = requests.request("GET", url, params=query)

    if int(response.status_code) != 200:
        print("\nError receiving labels from trello.com.\nExiting program")
        exit()

    allLabels = json.loads(response.text)

    if len(allLabels) != 0:
        print("\nAvailable labels are:")
        for i in range(len(allLabels)):
            print(str(i + 1) + ". Name: " + str(allLabels[i]["name"]) + " Color: " + str(allLabels[i]["color"]))

        print("Choose the labels you want to add and enter the numbers preceding them. Enter 0 when finished.\n")
        num = -1
        choices = set()    
        while num != 0:
            try:
                num = int(input())
                if num > 0 and num < len(allLabels) + 1:
                    choices.add(num - 1)
                elif num != 0:
                    raise Exception("Integer out of range")
            except:
                print("\nEnter an integer value between 1 and " + str(len(allLabels)) + " or 0 when finished.\n")
                num = -1
        
        newLabels = []
        for index in choices:
            newLabels.append(allLabels[index]["id"])
        query['idLabels'] = ','.join(newLabels)
    
    url = "https://api.trello.com/1/cards"
    headers = {"Accept": "application/json"}
    query['idList'] = idList
    query['name'] = title
    query['desc'] = comment
    response = requests.request("POST", url, headers=headers, params=query)
    
    if int(response.status_code) != 200:
        print("\nError adding card to trello.com.\nExiting program")
        exit()

    print("\nWould you like to continue adding cards to this list?\n\nrespond \"yes\" or \"no\"\n")
    response = input()
    while response != 'yes' and response != 'no':
        print("\nrespond \"yes\" or \"no\"\n")
        response = input()
    if response == 'yes':
        return True
    else:
        return False

def getList(name, board) -> str:
    global userInfo

    url = "https://api.trello.com/1/boards/" + board + "/lists"
    headers = {"Accept": "application/json"}
    query = {'key': '4f9c2c7240849c11b5c5d3723d08c7a4', 'token': userInfo[name][0]}
    response = requests.request("GET", url, headers=headers, params=query)
    
    if int(response.status_code) != 200:
        print("\nError receiving lists from trello.com.\nExiting program")
        exit()

    lists = json.loads(response.text)

    if len(lists) == 0:
        print("\nThere are currently no lists on this board. This program is only made to create cards. Create a list on trello.com and return here when you want to add a card.\n")
        print("\nExiting program")
        exit()
    elif len(lists) == 1:
        currList = None
        for item in lists:
            currList = item
        print("\nChoosing list: " + currList["name"])
        return currList["id"]
    else:
        print("\nCurrent lists are:")
        listDict = {}
        for currList in lists:
            print("- " + currList['name'])
            listDict[currList['name']] = currList['id']
        print("Choose the list you want to add a card to\n")
        listName = input()
        while listName not in listDict:
            print("\nError: Invalid list")
            print("Current lists are:")
            for key in listDict:
                print("- " + str(key))
            print("Choose the list you want to add a card to\n")
            listName = input()
        return listDict[listName]

def getBoard(name) -> str:
    global userInfo

    url = "https://api.trello.com/1/members/" + userInfo[name][1] + "/boards"
    headers = { "Accept": "application/json" }
    query = { 'key': '4f9c2c7240849c11b5c5d3723d08c7a4', 'token': userInfo[name][0]}
    response = requests.request("GET", url, headers=headers, params=query)

    if int(response.status_code) != 200:
        print("\nError obtaining data with the current user information, try making a new user.\n")
        exit()

    boards = json.loads(response.text)
    
    if len(boards) == 0:
        print("\nYou currently are not a member of a board. This program is only made to create cards. Create a board on trello.com and return here when you want to add a card.\n")
        print("\nExiting program")
        exit()
    elif len(boards) == 1:
        board = None
        for item in boards:
            board = item
        print("\nChoosing board: " + board["name"])
        return board["id"]
    else:
        print("\nCurrent boards are:")
        boardDict = {}
        for board in boards:
            print("- " + board['name'])
            boardDict[board['name']] = board['id']
        print("Choose the board you want to add a card to\n")
        board = input()
        while board not in boardDict:
            print("\nError: Invalid board")
            print("Current boards are:")
            for key in boardDict:
                print("- " + str(key))
            print("Choose the board you want to add a card to\n")
            board = input()
        return boardDict[board]


# From input, this function gets the user's name that matches one that is saved, or creates a new one
# and gets the token and member id to store in the users.json file
def getName() -> str:
    global userInfo

    print("\nEnter username or \"new user\":\n")
    name = input()
    while name not in userInfo and name != "new user":
        print("\nError: Invalid username")
        print("Enter username or \"new user\":\n")
        name = input()
    if name == "new user":
        print("\nInput new username:\n")
        name = input()
        while name == "new user" or name == "":
            print("\nChoose a better name.\n")
            name = input()
        print("\nGo to https://trello.com/1/authorize?key=4f9c2c7240849c11b5c5d3723d08c7a4&name=SimpleBASHScript&expiration=never&response_type=token&scope=read,write\n")
        print("Follow the directions to create a token. Enter the token string:\n")

        valid = False
        while not valid:
            token = input()
            memberid = ""

            url = "https://api.trello.com/1/tokens/" + token + "/member"
            headers = {"Accept": "application/json"}
            query = {'key': '4f9c2c7240849c11b5c5d3723d08c7a4', 'token': token}
            response = requests.request("GET", url, headers=headers, params=query)

            if int(response.status_code) == 200:
                valid = True
                member = json.loads(response.text)
                memberid = member["id"]
            else:
                print("\nError: Token isn't valid. Check the input and try again.\n")

        userInfo[name] = [token, memberid]
        with open('users.json', 'w') as w:
            json.dump(userInfo, w)
    return name

def main():
    print("_______________________\nTrello Card Adder\n_______________________")
    global userInfo
    with open('users.json', 'r') as r:
        userInfo = json.load(r)

    name = getName()
    board = getBoard(name)
    category = getList(name, board)
    while makeNote(name, board, category):
        True

    print("\nExiting program. Goodbye!")

if __name__ == "__main__":
    main()